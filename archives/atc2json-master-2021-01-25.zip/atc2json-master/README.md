# atc2json
converts AliveCor ATC files to JSON format
